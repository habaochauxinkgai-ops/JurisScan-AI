# JurisScan AI — bản chạy thử

## Có gì trong dự án?
- `index.html`: website một trang bằng HTML/CSS/JavaScript.
- Quét QR qua camera (nếu trình duyệt hỗ trợ và được cấp quyền).
- Tải ảnh PNG/JPEG/WebP để giải mã QR (tối đa 8 MB).
- Phân tích quy tắc cơ bản: nhận diện JSON/URL/văn bản, trích xuất một số trường có sẵn, báo trường còn thiếu.
- Có backend Node.js cục bộ để thử truy cập và trích xuất văn bản từ một số tên miền HTTPS công khai trong danh sách cho phép.
- Phân loại sơ bộ tên miền cơ quan nhà nước trong danh sách cấu hình và tên miền báo chí; hiển thị tiêu đề, trích đoạn, mã HTTP và cảnh báo giới hạn.
- Lưu bản ghi trong LocalStorage của trình duyệt.
- Tìm kiếm/xem/xóa bản ghi và xuất báo cáo CSV.
- Dashboard, phân tích thủ công, nhật ký hoạt động, trạng thái tính năng.

## Chạy trên Windows (bản có phân tích URL)
1. Cài Node.js 18 trở lên từ trang chính thức: https://nodejs.org/
2. Giải nén ZIP và mở thư mục `JurisScan_AI`.
3. Nhấp vào thanh địa chỉ của File Explorer, gõ `cmd` rồi nhấn Enter (hoặc mở Terminal trong thư mục).
4. Chạy lệnh:
   ```bash
   npm start
   ```
5. Mở `http://127.0.0.1:8000` trong Chrome.
6. Quét QR chứa URL hoặc vào **Phân tích thông tin**, dán URL rồi chọn **Truy cập & phân tích link**.

Để tắt máy chủ, quay lại cửa sổ Terminal và nhấn `Ctrl+C`.

## Danh sách URL được hỗ trợ trong bản demo
- Cơ quan nhà nước (được gắn nhãn tên miền chính thức theo cấu hình): `moet.gov.vn`, `moj.gov.vn`, `vanban.chinhphu.vn`, `vbpl.vn`, `quochoi.vn`, `chinhphu.vn`, `baochinhphu.vn`, `xaydungchinhsach.chinhphu.vn`.
- Một số trang báo chí (được phân biệt rõ, không gắn nhãn cơ quan ban hành): `vnexpress.net`, `tuoitre.vn`, `thanhnien.vn`, `dantri.com.vn`.
- Chỉ chấp nhận HTTPS; chuyển hướng không tự động theo trong bản demo. Các trang có tường đăng nhập, chống bot, định dạng không phải HTML hoặc lỗi mạng có thể không đọc được.

## Lưu ý quan trọng
- Thư viện `jsQR` được tải từ CDN nên cần Internet để giải mã QR.
- Camera thường yêu cầu `localhost` hoặc HTTPS và quyền camera.
- Bản demo có backend Node.js chạy cục bộ để tải trang từ danh sách tên miền cho phép; dữ liệu bản ghi vẫn lưu trong LocalStorage, không có tài khoản hay database server.
- Đây là bộ trích xuất HTML theo quy tắc, **chưa tích hợp mô hình AI**, chưa đối chiếu nội dung với một kho văn bản pháp luật chính thức, chưa xác minh hiệu lực văn bản, chưa có xác thực/phân quyền thật, chưa có nhật ký chống sửa đổi.
- Không nhập hồ sơ tư pháp thật hoặc dữ liệu cá nhân nhạy cảm vào bản demo.
- Tên miền nằm trong danh sách cơ quan nhà nước chỉ cho biết nó khớp danh sách cấu hình; **không chứng minh nội dung trang, tài liệu hay thông tin cụ thể là đúng hoặc còn hiệu lực**. Một trang báo chí cũng không được coi là nguồn ban hành chính thức.
- Backend chỉ cho phép danh sách tên miền định trước và chặn URL không hợp lệ, IP trực tiếp, HTTP thường, một số địa chỉ mạng riêng và chuyển hướng. Đây vẫn chỉ là demo; triển khai công khai cần kiểm soát egress và biện pháp chống SSRF/DNS rebinding chuyên nghiệp.
- Không dùng bản demo làm hệ thống nghiệp vụ tư pháp thật. Muốn triển khai thực tế cần backend, database, xác thực/phân quyền phía server, HTTPS, kiểm thử bảo mật và các tích hợp được phê duyệt.

## Cấu trúc
```text
JurisScan_AI/
├── index.html
├── server.js
├── package.json
└── README.md
```


### Giới hạn khi đọc link (bản mở rộng)
- Có thể thử đọc nhiều tên miền HTTPS công khai hơn; vẫn chặn địa chỉ IP trực tiếp, localhost và địa chỉ mạng riêng để giảm rủi ro truy cập nội bộ.
- Bản demo không tự theo chuyển hướng HTTP 3xx. Nếu website chuyển hướng, hãy kiểm tra URL đích trước khi thử lại.
- Một số website chặn bot, yêu cầu đăng nhập, tải nội dung bằng JavaScript hoặc không trả HTML; khi đó có thể không đọc được.
- Phân loại tên miền chỉ là gợi ý. Muốn kết luận thông tin đúng/sai phải đối chiếu tài liệu với nguồn chính thức độc lập; không coi việc mở được trang là xác minh tính đúng đắn.
