const http = require('node:http');
const dns = require('node:dns').promises;
const net = require('node:net');
const fs = require('node:fs');
const path = require('node:path');
const { URL } = require('node:url');

const ROOT = __dirname;
const PORT = Number(process.env.PORT || 8000);
// Phân loại một số tên miền quen thuộc; các tên miền HTTPS công khai khác vẫn có thể được thử truy cập.
const OFFICIAL = ['moet.gov.vn','moj.gov.vn','vanban.chinhphu.vn','vbpl.vn','quochoi.vn','chinhphu.vn','baochinhphu.vn','xaydungchinhsach.chinhphu.vn'];
const MEDIA = ['vnexpress.net','tuoitre.vn','thanhnien.vn','dantri.com.vn'];
const isIn = (host, list) => list.some(d => host === d || host.endsWith('.'+d));
const isOfficial = host => isIn(host, OFFICIAL);
const isMedia = host => isIn(host, MEDIA);
function isPrivateIp(ip) {
  if (net.isIPv4(ip)) { const [a,b] = ip.split('.').map(Number); return a===10 || a===127 || a===0 || (a===169&&b===254) || (a===172&&b>=16&&b<=31) || (a===192&&b===168) || a>=224; }
  if (net.isIPv6(ip)) { const x=ip.toLowerCase(); return x==='::1' || x==='::' || x.startsWith('fc') || x.startsWith('fd') || x.startsWith('fe8') || x.startsWith('fe9') || x.startsWith('fea') || x.startsWith('feb') || x.startsWith('::ffff:127.') || x.startsWith('::ffff:10.'); }
  return true;
}
function validateUrl(input) {
  let u; try { u = new URL(input); } catch { throw new Error('URL không hợp lệ.'); }
  if (u.protocol !== 'https:') throw new Error('Bản demo chỉ cho phép HTTPS.');
  if (u.username || u.password) throw new Error('URL có thông tin đăng nhập bị từ chối.');
  if (u.port && u.port !== '443') throw new Error('Cổng mạng không được hỗ trợ.');
  const host = u.hostname.toLowerCase().replace(/\.$/,'');
  if (net.isIP(host) || !host.includes('.') || host === 'localhost' || host.endsWith('.localhost') || host.endsWith('.local')) throw new Error('Tên miền này không được hỗ trợ. Hãy nhập một tên miền công khai, ví dụ https://vnexpress.net/.');
  return {u, host};
}
function cleanText(html) {
  return html.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,' ').replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,' ').replace(/<(br|\/p|\/div|\/h[1-6]|\/li|\/article|\/section)[^>]*>/gi,'\n').replace(/<[^>]+>/g,' ').replace(/&nbsp;|&#160;/gi,' ').replace(/&amp;/gi,'&').replace(/&quot;/gi,'"').replace(/&#39;|&apos;/gi,"'").replace(/&lt;/gi,'<').replace(/&gt;/gi,'>').replace(/&#(\d+);/g,(_,n)=>String.fromCharCode(Number(n))).replace(/[ \t\r]+/g,' ').replace(/\n\s*\n+/g,'\n').trim();
}
async function analyzeUrl(input) {
  const {u,host} = validateUrl(input);
  // Resolve and reject private/local targets before request. For production, enforce egress controls
  // and pin the validated address at connection time to fully mitigate DNS rebinding.
  const addresses = await dns.lookup(host,{all:true,verbatim:true});
  if (!addresses.length || addresses.some(x=>isPrivateIp(x.address))) throw new Error('Tên miền phân giải tới địa chỉ mạng không được phép.');
  const controller = new AbortController(); const timer=setTimeout(()=>controller.abort(),10000);
  let response;
  try { response = await fetch(u.href,{method:'GET',redirect:'manual',signal:controller.signal,headers:{'user-agent':'JurisScanAI-Demo/1.0 (public page text extraction)','accept':'text/html,application/xhtml+xml'}}); }
  finally { clearTimeout(timer); }
  if (response.status >= 300 && response.status < 400) throw new Error('Trang chuyển hướng. Bản demo không tự đi theo chuyển hướng; hãy kiểm tra URL đích trước.');
  if (!response.ok) throw new Error('Trang trả về HTTP '+response.status+'.');
  const ct = response.headers.get('content-type') || '';
  if (!ct.includes('text/html') && !ct.includes('application/xhtml+xml')) throw new Error('Trang không trả về HTML có thể đọc trong bản demo.');
  const html = (await response.text()).slice(0, 1_500_000);
  const title = (html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1] || '').replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim().slice(0,300);
  const text = cleanText(html).slice(0,12000);
  return {url:u.href,finalUrl:u.href,host,title,httpStatus:response.status,textLength:text.length,excerpt:text.slice(0,2200),sourceClass:isOfficial(host)?'official':isMedia(host)?'media':'unknown',note:isOfficial(host)?'Tên miền khớp danh sách cơ quan nhà nước được cấu hình trong bản demo. Điều này không xác nhận mọi nội dung là đúng hoặc văn bản còn hiệu lực.':isMedia(host)?'Đã trích xuất nội dung từ tên miền báo chí/thông tin. Đây không phải xác nhận của cơ quan ban hành; cần đối chiếu nguồn chính thức độc lập.':'Đã thử trích xuất nội dung từ trang công khai. Tên miền chưa được phân loại là nguồn chính thức; cần đối chiếu nguồn đáng tin cậy độc lập.'};
}
const types = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.md':'text/plain; charset=utf-8'};
const server = http.createServer(async (req,res)=>{
  const origin = req.headers.origin;
  if (origin && !/^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(origin)) { res.writeHead(403); return res.end('Forbidden'); }
  if (req.method==='POST' && req.url==='/api/analyze-url') {
    let body=''; req.on('data',chunk=>{body+=chunk;if(body.length>10000){req.destroy();}});
    req.on('end',async()=>{try{const payload=JSON.parse(body||'{}');const result=await analyzeUrl(String(payload.url||''));res.writeHead(200,{'content-type':'application/json; charset=utf-8','cache-control':'no-store'});res.end(JSON.stringify(result));}catch(e){res.writeHead(400,{'content-type':'application/json; charset=utf-8','cache-control':'no-store'});res.end(JSON.stringify({error:e.name==='AbortError'?'Trang phản hồi quá lâu (hết thời gian chờ).':e.message||'Không thể phân tích URL.'}));}});return;
  }
  if (req.method!=='GET' && req.method!=='HEAD') {res.writeHead(405);return res.end('Method not allowed');}
  let pathname; try {pathname=decodeURIComponent(new URL(req.url,'http://localhost').pathname);} catch {res.writeHead(400);return res.end('Bad request');}
  if (pathname==='/') pathname='/index.html';
  const target=path.resolve(ROOT,'.'+pathname);
  if (!target.startsWith(ROOT+path.sep) || !fs.existsSync(target) || !fs.statSync(target).isFile()) {res.writeHead(404);return res.end('Not found');}
  res.writeHead(200,{'content-type':types[path.extname(target)]||'application/octet-stream','x-content-type-options':'nosniff','referrer-policy':'no-referrer'});
  if(req.method==='HEAD')return res.end(); fs.createReadStream(target).pipe(res);
});
server.listen(PORT,'127.0.0.1',()=>console.log(`JurisScan AI đang chạy tại http://127.0.0.1:${PORT}`));
